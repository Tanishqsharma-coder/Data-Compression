#include <bits/stdc++.h>

using namespace std;


string encode(string str)
{

    string encoding = "";
    int count;

    for (int i = 0; str[i]; i++)
    {

        count = 1;
        while (str[i] == str[i + 1]) {
            count++,
            i++;
        }

        encoding += to_string(count) + str[i];
        ofstream filestream("output.txt");
            filestream << encoding;

    }

    return encoding;

}

int main()
{
    ifstream infile;
    string str;
    infile.open("input.txt");
    string s="";
    cout << "Reading from the file" << endl;
    while(getline(infile,str))
    {

       s += str;

    }
    cout << str;
    cout << "\n" << "Encoded data is: ";
    string temp = encode(str);
    cout << temp;

    infile.close();

    return 0;
}
