#include <bits/stdc++.h>
#include<string.h>
#define MAX_TREE_HT 256
using namespace std;

struct rotation {
	int index;
	char* suffix;
};

struct node {
	int data;
	struct node* next;
};


int cmpfunc2(const void* a, const void* b)
{
	const char* ia = (const char*)a;
	const char* ib = (const char*)b;
	return strcmp(ia, ib);
}

struct node* getNode(int i)
{
	struct node* nn =
		(struct node*)malloc(sizeof(struct node));
	nn->data = i;
	nn->next = NULL;
	return nn;
}

void addAtLast(struct node** head, struct node* nn)
{
	if (*head == NULL) {
		*head = nn;
		return;
	}
	struct node* temp = *head;
	while (temp->next != NULL)
		temp = temp->next;
	temp->next = nn;
}

void* computeLShift(struct node** head, int index,	int* l_shift)
{
	l_shift[index] = (*head)->data;
	(*head) = (*head)->next;
}

string invert(char bwt_arr[])
{
	int i,len_bwt = strlen(bwt_arr);
	char* sorted_bwt = (char*)malloc(len_bwt * sizeof(char));
	strcpy(sorted_bwt, bwt_arr);
	int* l_shift = (int*)malloc(len_bwt * sizeof(int));

	int x = 0;
	for(int i=0 ; i<strlen(bwt_arr) ;i++)
    {

        if(bwt_arr[i]=='#')
            break;

        x++;
    }

	qsort(sorted_bwt, len_bwt, sizeof(char), cmpfunc2);

	struct node* arr[128] = { NULL };

	for (i = 0; i < len_bwt; i++) {
		struct node* nn = getNode(i);
		addAtLast(&arr[bwt_arr[i]], nn);
	}
	for (i = 0; i < len_bwt; i++)
		computeLShift(&arr[sorted_bwt[i]], i, l_shift);

	string str="";
	for (i = 0; i < len_bwt; i++) {
		x = l_shift[x];
		str = str + bwt_arr[x];

	}

	return str;
}



int cmpfunc(const void* x, const void* y)
{
	struct rotation* rx = (struct rotation*)x;
	struct rotation* ry = (struct rotation*)y;
	return strcmp(rx->suffix, ry->suffix);
}


int* computeSuffixArray(char* input_text, int len_text)
{

	struct rotation suff[len_text];

	for (int i = 0; i < len_text; i++) {
		suff[i].index = i;
		suff[i].suffix = (input_text + i);
	}

	qsort(suff, len_text, sizeof(struct rotation),cmpfunc);

	int* suffix_arr
		= (int*)malloc(len_text * sizeof(int));
	for (int i = 0; i < len_text; i++)
		suffix_arr[i] = suff[i].index;

	return suffix_arr;
}


char* findLastChar(char* input_text,
				int* suffix_arr, int n)
{

	char* bwt_arr = (char*)malloc(n * sizeof(char));
	int i;
	for (i = 0; i < n; i++) {
		int j = suffix_arr[i] - 1;
		if (j < 0)
			j = j + n;

		bwt_arr[i] = input_text[j];
	}

	bwt_arr[i] = '\0';

	return bwt_arr;
}

map<char, string> codes;


map<char, int> freq;

struct MinHeapNode
{
    char data;
    int freq;
    MinHeapNode *left, *right;

    MinHeapNode(char data, int freq)
    {
        left = right = NULL;
        this->data = data;
        this->freq = freq;
    }
};


struct compare
{
    bool operator()(MinHeapNode* l, MinHeapNode* r)
    {
        return (l->freq > r->freq);
    }
};


void printCodes(struct MinHeapNode* root, string str)
{
    if (!root)
        return;
    if (root->data != '$')
        cout << root->data << ": " << str << "\n";
    printCodes(root->left, str + "0");
    printCodes(root->right, str + "1");
}

void storeCodes(struct MinHeapNode* root, string str)
{
    if (root==NULL)
        return;
    if (root->data != '$')
        codes[root->data]=str;
    storeCodes(root->left, str + "0");
    storeCodes(root->right, str + "1");
}


priority_queue<MinHeapNode*, vector<MinHeapNode*>, compare> minHeap;


void HuffmanCodes(int size)
{
    struct MinHeapNode *left, *right, *top;
    for (map<char, int>::iterator v=freq.begin(); v!=freq.end(); v++)
        minHeap.push(new MinHeapNode(v->first, v->second));
    while (minHeap.size() != 1)
    {
        left = minHeap.top();
        minHeap.pop();
        right = minHeap.top();
        minHeap.pop();
        top = new MinHeapNode('$', left->freq + right->freq);
        top->left = left;
        top->right = right;
        minHeap.push(top);
    }
    storeCodes(minHeap.top(), "");
}


void calcFreq(string str, int n)
{
    for (int i=0; i<str.size(); i++)
        freq[str[i]]++;
}

string decode_file(struct MinHeapNode* root, string s)
{
    string ans = "";
    struct MinHeapNode* curr = root;
    for (int i=0;i<s.size();i++)
    {
        if (s[i] == '0')
           curr = curr->left;
        else
           curr = curr->right;

        if (curr->left==NULL and curr->right==NULL)
        {
            ans += curr->data;
            curr = root;
        }
    }

    return ans+'\0';
}

string convertToString(char* a, int size)
{
    int i;
    string s = "";
    for (i = 0; i < size; i++) {
        s = s + a[i];
    }
    return s;
}



int main()
{
    ifstream infile;
    string data;
    infile.open("input.txt");
    string s="";
    cout << "Reading from the file" << endl;
    while(getline(infile,data))
    {

       s += data;

    }

    char input_text[data.length() + 2];
    strcpy(input_text, data.c_str());
    for (int i = 0; i < data.length(); i++)
        {
           input_text[i]=data[i];
        }
    char app[]="#";
    strcat(input_text,app);
    cout << "\n" << "Origina Data :- ";
    cout << input_text;
	int len_text = strlen(input_text);

	int* suffix_arr = computeSuffixArray(input_text, len_text);
	char* bwt_arr = findLastChar(input_text, suffix_arr, len_text);
	cout << "\n\n" << "Burrows Wheeler transform of the data :- " << bwt_arr;
	int len_text2 = strlen(bwt_arr);
    string str=convertToString(bwt_arr,len_text2);

    string encodedString, decodedString;
    calcFreq(str, str.length());
    HuffmanCodes(str.length());

    cout << "\nCharacter With there Frequencies:\n";
    for (auto v=codes.begin(); v!=codes.end(); v++)
        cout << v->first <<' ' << v->second << endl;


    for (auto i: str)
        {
            encodedString+=codes[i];

        }
    cout << "\n";
    cout << "\nEncoded Huffman data:\n" << encodedString << endl;

    decodedString = decode_file(minHeap.top(), encodedString);
    cout << "\nDecoded Huffman Data :- " << decodedString;

    ofstream filestream1("output_decoded_huffman.txt");
    int j=0;
    while(decodedString[j]!=NULL)
    {
        if(decodedString[j]==' ' && decodedString[j+1]==' ')
        {
           j++;
        }
        else
           {
            filestream1 << decodedString[j];
		    filestream1 << "";
		    j++;
           }

    }
    filestream1.close();

    char* bwt_arr2;
    bwt_arr2 = &decodedString[0];
    string invert_bwt=invert(bwt_arr2);
    ofstream filestream2("output_invertbwt.txt");
    int i=0;

    while(invert_bwt[i]!=NULL)
    {
        if(invert_bwt[i]=='#')
        {
            i++;
        }
        else if(invert_bwt[i]==' ' && invert_bwt[i+1]==' ')
        {
           i++;
        }
        else
           {
            filestream2 << invert_bwt[i];
		    filestream2 << "";
		    i++;
           }

    }
    cout << "\n\nBurrows wheeler inverse of the decoded Huffman data: \n";
    cout << invert_bwt;
    filestream2.close();
    infile.close();

    return 0;
}
